---
layout: twocol
title: Trade-offs in Fair Redistricting Online Appendix
permalink: /tradeoffs-fair-dist/
order: 7
customjs: 

invisible: true
---


<style>

</style>



## *Trade-offs in Fair Redistricting* -- Online Appendix

This is the online appendix for the paper [*Trade-Offs in Fair Redistricting*](../assets/papers/aies-tradeoffs-fair-redist.pdf), to appear at [AI, Ethics, and Society 2020](https://aies-conference.com).   


In the paper, we explore empirically the 'price' one must pay in terms of the compactness of districts in order to improve the partisan 
symmetry of a plan (and vice versa) in North Carolina and Pennsylvania, and in doing so, find a collection of plans along the empirical 
Pareto frontier of compactness and partisan symmetry.  There are 13 Pareto-dominant plans for North Carolina and 25 
for Pennsylvania, including the four displayed in the paper.  Click a state below to see the plans for that state.  

<div style="text-align: center">
<div style="display: inline-block; text-align: center; width:325px">
<a href="nc-maps"> 
    <div>North Carolina</div>
    <img border="0" alt="North Carolina" src="/assets/images/nc_outline.png" height="150">
</a>
</div>


<div style="display: inline-block; text-align: center; width:325px">
<a href="pa-maps">
    <div>Pennsylvania</div>
    <img border="0" alt="Pennsylvania" src="/assets/images/pa_outline.png" height="150">
</a>
</div>

</div>
<br />
A Jupyter notebook containing a skeleton of the code used to perform the Markov chain Monte Carlo search is [here (nbviewer)](https://nbviewer.jupyter.org/github/zschutzman/zschutzman.github.io/blob/master/tradeoffs-fair-dist/tradeoffs-skeleton.ipynb).  



The paper and/or this appendix can be cited with the following BibTeX, which will be updated once the proceedings are published.
```
@article{schutzman2020tradeoffs,
	author={Zachary Schutzman},
	title={Trade-Offs in Fair Redistricting},
	journal={Proceedings of the 2020 
		AAAI/ACM Conference on AI, Ethics, 
		and Society {(forthcoming)}},
	year={2020},
}
```


